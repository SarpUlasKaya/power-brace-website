Hello!

First of all, thank you so much for reading! If you did not skip the Author's Note / Preface section while doing so, you may remember that Power Brace was initially a video game idea rather than a novel. This folder contains a bunch of sketches and old writing from the days when it was still a video game idea, ranging from its absolute earliest prototypes to what it looked like right before I fully pivoted into its novelization. It contains the following:

1. Character Sketches
Unfortunately, I didn't spend much time sketching chatacters overall, so you will only find two of them sketched at all here. Saleena, and her sister Vica. Here's a fun fact though: I was still working on merely the basic outline of Saleena's backstory at the time, bouncing around a lot of ideas like a strict family, a love for nature, an introverted shy personality and stuff like that. I was yet to even set a strong foundation though, let alone finally start writing it in full detail. That's where the sketches came in. The Vica sketch was actually another attempt at a Saleena sketch at first, but it ended up looking like a completely different person by the end, which is how Vica was born. She was the missing piece of the Saleena puzzle, and the foundation was finally set. From then on, I was finally able to fully flesh out her story.
Also, you're probably wondering what those stains on some of the Saleena sketches are. I was confused too since they just seemed to randomly appear on any piece of paper I left on my desk sometimes. I later found out that it's what happens if you have oily skin and put your headphones on top of a piece of paper after using them. I am truly sorry if you are disgusted after reading that. If it makes you feel any better, I've been paying attention ever since learning it and never repeated the same mistake :)

2. Gameplay
Self explanatory. It contains all the ideas I had written down for gameplay, and even prepared an awful visual for. I am truly sorry for not crediting the artwork and assets I used for that, as I did not have the sensibilities to do so back then. I've lost the sources now, but will update it here if I end up finding them again.

3. Menus
Please don't ask what "Advanced Melee" is. Fucking stupid is what it was, so it got scrapped even before I wrote either the Gameplay or the Menus document. Also, "Ecstatic Overcharge" being fully readable in one of the sketches is unfortunate, as it was the worst name idea I had for the state. It was at first called "Emotional Overcharge" which actually stuck around for quite a while. But after a while, I was unsatisfied for some reason and thought "Ecstatic Overcharge" was somehow better for a *very brief* period, before finally just calling it "Overcharge" in the final version. I can't believe my only sketch where the name is fully visible was from that brief period. God. Horrible.

4. Old Bracelet Sketches
As you can probably tell if you've read the current version of Power Brace or even looked at its cover art, the thin little bracelets in these sketches are a *much* earlier idea than the final bulky ones thick enough to deflect enemy attacks and such. Funnily enough, some aspects of their designs did end up on the final cover art though after I showed these sketches to Shiki while discussing how to go about it. They had the brilliant idea of using these original designs as patterns around the bracelets on the cover art. You can see them if you look closely :)

5. Early Prototypes
Just general information on each previous version of Power Brace along with some cringe writing samples from them.

Enjoy!
